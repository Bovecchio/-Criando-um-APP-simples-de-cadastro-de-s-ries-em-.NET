<p><img src="https://user-images.githubusercontent.com/63436406/132139699-13c81f1b-5e46-425c-99b6-ae6ca761f4b9.png" align="left" height="150px" width="150px">
    <h1># Criando um APP simples de cadastro de séries em .NET</h1> 
    <p align="justify">
    Aprenda como criar um algorítmo simples de cadastro de séries para praticar seus conhecimentos de orientação a objetos, o principal paradigma de programação utilizada no mercado. Nesse projeto você vai aprender: Como pensar orientado a objetos, como modelar o seu domínio, como utilizar recursos de coleção para salvar seus dados em memória.
    </p>
</p>      

---

<br>
    <code><a href="https:/discord.com">
        <img src="https://img.shields.io/badge/Léo Albergaria%20-%237289DA.svg?&style=for-the-badge&logo=discord&logoColor=white" /></a></code>
    <code><a href="https://www.linkedin.com/in/adm-leo-albergaria/">
        <img src="https://img.shields.io/badge/linkedin%20-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white" /></a></code>
<br>     

<a href="https://www.digitalinnovation.one/">
    <img src="https://user-images.githubusercontent.com/63436406/127776292-9ec4809a-1137-4dc8-b493-7de0186fd55c.png" align="right" height="80px" width="250px" ></a>
